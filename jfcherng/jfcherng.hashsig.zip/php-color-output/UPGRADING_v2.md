## Upgrading to v2

- The class name/namespace has been changed from `Jfcherng\Color\Colorful` to `Jfcherng\Utility\CliColor`.
- The names of helper functions have been changed from `str_color/str_nocolor` to `str_cli_color/str_cli_nocolor`.
